'''hw6p5.py

   This is the skeleton code for HW6 Problem 5.  Please EDIT.

   This uses the inverse kinematics from Problem 4, but adds a more
   complex trajectory.

   Node:        /generator
   Publish:     /joint_states           sensor_msgs/JointState

'''

import rclpy
import numpy as np

from math import pi, sin, cos, acos, atan2, sqrt, fmod, exp

# Grab the utilities
from hw5code.GeneratorNode      import GeneratorNode
from hw5code.TransformHelpers   import *
from hw5code.TrajectoryUtils    import *

# Grab the general fkin from HW5 P5.
from hw5code.KinematicChain     import KinematicChain


#
#   Trajectory Class
#
class Trajectory():
    # Initialization.
    def __init__(self, node):
        # Set up the kinematic chain object.
        self.chain = KinematicChain(node, 'world', 'tip', self.jointnames())

        self.q0 = np.radians(np.array([0, 90, -90, 0, 0, 0]).reshape((-1,1)))
        self.p0 = np.array([0.0, 0.55, 1.0]).reshape((-1,1))
        self.R0 = Reye()
        self.left = pxyz(0.3,0.5,0.15)
        self.right = pxyz(-0.3,0.5,0.15)
        # Initialize the current/starting joint position.
        self.q  = self.q0
        self.R1 = 0
        self.R2 = 0
        self.R3 = 0

    # Declare the joint names.
    def jointnames(self):
        # Return a list of joint names FOR THE EXPECTED URDF!
        return ['theta1', 'theta2', 'theta3', 'theta4', 'theta5', 'theta6']

    # Evaluate at the given time.  This was last called (dt) ago.
    def evaluate(self, t, dt):
 #       temp_t = fmod(t-3, 5)
 #       if t<3.0:
 #           q = self.q0
 #           (x,xdot) =goto(t,3,self.p0,self.right)
 #           
 #       else:
 #           if temp_t<2.5:
 #              return None
        if t < 3.0:
            # Approach movement:
            (s0, s0dot) = goto(t, 3.0, 0.0, 1.0)

            pd = self.p0 + (self.right - self.p0) * s0
            vd =           (self.right - self.p0) * s0dot

            Rd = Rotz(0)
            wd = pxyz(0,0,0)
            print(Rd)
        else:
            
            # Pre-compute the path variables.  To show different
            # options, we compute the position path variable using
            # sinusoids and the orientation variable via splines.
            t1 = (t-3) % 5.0
            sp    =      abs( cos(pi/2 * t1/1.25))
            spdot = -pi/2.5 * sin(pi/2 * t1/1.25)


            if t1 < 1.25:
                (sR, sRdot) = goto(t1,     1.25, 0,  1)
                pd = self.right- (self.right-self.p0) * (1-sp)
                vd =            (self.right-self.p0) * spdot
                Rd = Rotz(pi/2 * sR)
                wd = ez() * (pi/2 * sRdot)
                self.R1 = Rd
            elif 1.25<=t1<2.5:
                (sR, sRdot) = goto(t1-1.25, 1.25,  0, 1.0)
                pd = self.p0-(self.p0-self.left) * sp
                vd =                            (self.p0-self.left) * spdot
                Rd = Roty(-pi/2 * sR)@self.R1
                wd = ey() * (-pi/2 * sRdot)
                self.R2 = Rd
            elif 2.5<=t1<3.75:
                (sR, sRdot) = goto(t1-2.5, 1.25,  0, 1.0)
                pd = self.left- (self.left-self.p0) * (1-sp) 
                vd =                            (self.left-self.p0) * spdot
                Rd = Roty(pi/2 * sR)@self.R2
                wd = ey() * (pi/2 * sRdot)
                self.R3 = Rd
            else:
                (sR, sRdot) = goto(t1-3.75, 1.25,  0, 1.0)
                pd = self.p0 -(self.p0-self.right) * sp  
                vd =                            (self.p0-self.right) * spdot
                Rd = Rotz(-pi/2 * sR)@self.R3
                wd = ez() * (-pi/2 * sRdot)
            # Use the path variables to compute the trajectory.
            
            # print(t)
            # print(pd)
            #Rd = Rotz(pi/2 * sR)
            #wd = ez() * (pi/2 * sRdot)

        qlast = self.q 
        print(Reye())
        print(Rotz(pi/2)@Roty(-pi/2))
        # Compute the old forward kinematics.
        (p, R, Jv, Jw) = self.chain.fkin(qlast)
        J = np.vstack((Jv,Jw))
        velocity = np.vstack((vd,wd))
        calerror = np.vstack((ep(pd,p),eR(Rd,R)))
        # Compute the inverse kinematics
        qdot = np.linalg.inv(J)@(velocity+20*calerror)

        # Integrate the joint position.
        q = qlast + dt * qdot
        
        # Save the data needed next cycle.
        self.q = q

        # Return the position and velocity as python lists.
        return (q.flatten().tolist(), qdot.flatten().tolist())


#
#  Main Code
#
def main(args=None):
    # Initialize ROS.
    rclpy.init(args=args)

    # Initialize the generator node for 100Hz udpates, using the above
    # Trajectory class.
    generator = GeneratorNode('generator', 100, Trajectory)

    # Spin, meaning keep running (taking care of the timer callbacks
    # and message passing), until interrupted or the trajectory ends.
    generator.spin()

    # Shutdown the node and ROS.
    generator.shutdown()
    rclpy.shutdown()

if __name__ == "__main__":
    main()
