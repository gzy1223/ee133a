import numpy as np
import matplotlib.pyplot as plt
# Grab the fkin and Jac from P1.
from hw5code.hw5p1 import fkin, Jac
from hw5code.TransformHelpers import *
def main():
    # Run the test case.  Suppress infinitesimal numbers.
    np.set_printoptions(suppress=True)

    xr = np.array([[1],[0],[1]])
    q = np.array([[np.radians(0)],
                  [np.radians(44.5)],
                  [np.radians(90)]])
    print('q:\n',       q)
    print('Jac(q):\n',  Jac(q))
    print("question2")
    U, S, VT = np.linalg.svd(Jac(q))
    print("U")
    print(U)
    print("S")
    print(S)
    print("VT")
    print(VT)
    qdot =  np.linalg.inv(Jac(q))@xr
    J = Jac(q)
    xdot = J@(qdot)
    print("qdot")
    print(qdot)
    print("xdot")
    print(xdot)

    print("question3")
    gamma = 0.01
    temp_w = np.eye(3)*gamma**2
    
    Jwinv = np.transpose(J)@np.linalg.inv(J@np.transpose(J)+temp_w)
    qdot = Jwinv@xr
    xdot = J@(qdot)
    print("qdot")
    print(qdot)
    print("xdot")
    print(xdot)

    print("question4")
    gamma = 0.1
    temp_w = np.eye(3)*gamma**2
    
    Jwinv = np.transpose(J)@np.linalg.inv(J@np.transpose(J)+temp_w)
    qdot = Jwinv@xr
    xdot = J@(qdot)
    print("qdot")
    print(qdot)
    print("xdot")
    print(xdot)   
    print("question5")
    gamma = 0.1
    q4index = 0
    for si in S:
        if abs(si)<gamma:
            si = si/(gamma**2)
        else:
            si = 1/si
        S[q4index] = si
        q4index = q4index+1
    print(S)
    JWplus = np.transpose(VT)@ np.diag(S) @np.transpose(U)
    qdot = JWplus@xr
    xdot = J@qdot
    print("qdot")
    print(qdot)
    print("xdot")
    print(xdot)

    
if __name__ == "__main__":
    main()
