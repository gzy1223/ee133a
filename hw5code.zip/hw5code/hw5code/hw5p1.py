'''hw5p1.py

   This is skeleton code for HW5 Problem 1.  Please EDIT.

   This should simply use NumPy to implement the known forward
   kinematics and Jacobian functions for the 3 DOF robot.

'''

import numpy as np


#
#  EXAMPLE CODE
#
#  TO SEE HOW TO USE NUMPY, LOOK AT NumPyExamples.py!
#
# REMOVE/COMMENT THIS OUT TO AVOID ALL THE EXTRA PRINTS
# import hw5code.NumPyExamples



#
#  Forward Kinematics
#
def fkin(q):
    # EDIT THIS CODE TO DO SOMETHING USEFUL!
    x = []
    x.append( -(np.cos(q[1])+np.cos(q[1]+q[2]))*np.sin(q[0]))
    x.append ( (np.cos(q[1])+np.cos(q[1]+q[2]))*np.cos(q[0]))
    x.append ( np.sin(q[1])+np.sin(q[1]+q[2]))
    x = np.array(x).reshape(-1,1) 
    
    # Return the tip position as a numpy 3x1 column vector.
    return x

##
#[[ -3780.17254456]
# [-17918.28007234]
# [ 39363.136727  ]]
#
#
#  Jacobian
#
def Jac(q):
    # EDIT THIS CODE TO DO SOMETHING USEFUL!

    J = np.eye(3)
    J = np.random.rand(3,3)
    J[0,0 ] = - np.cos(q[0])*(np.cos(q[1])+np.cos(q[1]+q[2]))
    J[1,0]  = -(np.cos(q[1])+np.cos(q[1]+q[2]))*np.sin(q[0])
    J[2,0]= 0
    J[0,1]= (np.sin(q[1])+np.sin(q[1]+q[2]))*np.sin(q[0])
    J[1,1]= -(np.sin(q[1])+np.sin(q[1]+q[2]))*np.cos(q[0])
    J[2,1]= np.cos(q[1])+np.cos(q[1]+q[2])
    J[0,2]= np.sin(q[0])*np.sin(q[1]+q[2])
    J[1,2]= -np.cos(q[0])*np.sin(q[1]+q[2])
    J[2,2]= np.cos(q[1]+q[2])

    # Return the Jacobian as a numpy 3x3 matrix.
    return J


#
#  Main Code
#
def main():
    # Run the test case.  Suppress infinitesimal numbers.
    np.set_printoptions(suppress=True)

    # Run the example code.  FEEL FREE TO REMOVE.


    # First (given) test case with following joint coordinates.  Make
    # q a column vector by writing it as a list of lists.
    print("TEST CASE #1:")
    q = np.array([[np.radians(0)],
                  [np.radians(44.5)],
                  [np.radians(90)]])
    print('q:\n',       q)
    print('fkin(q):\n', fkin(q))
    print('Jac(q):\n',  Jac(q))
    U, S, VT = np.linalg.svd(Jac(q))
    print(U)
    print(S)
    print(VT)
    # Second test case with following joint coordinates.  Make
    # q a column vector by explicitly reshaping.
    #print("TEST CASE #2")
    #q = np.radians(np.array([30, 30, 60])).reshape(3,1)
    #print('q:\n',       q)
    #print('fkin(q):\n', fkin(q))
    #print('Jac(q):\n',  Jac(q))

if __name__ == "__main__":
    main()
