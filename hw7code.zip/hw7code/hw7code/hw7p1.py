from sympy import symbols, sin, cos, Eq, solve, simplify

# Define the symbolic variables
l1, l2, theta1, theta2 = symbols('l1 l2 theta1 theta2')

# Define the equations based on the conditions for JJ^T = I
eq1 = Eq(l2**2 * sin(theta1 + theta2)**2 + (-l1 * sin(theta1) - l2 * sin(theta1 + theta2))**2, 1)
eq2 = Eq(l2**2 * cos(theta1 + theta2)**2 + (l1 * cos(theta1) + l2 * cos(theta1 + theta2))**2, 1)
eq3 = Eq(-l2**2 * sin(theta1 + theta2) * cos(theta1 + theta2) + (-l1 * sin(theta1) - l2 * sin(theta1 + theta2)) * (l1 * cos(theta1) + l2 * cos(theta1 + theta2)), 0)

# Attempt to solve the system of equations
# We will solve for theta2 in terms of the other variables
solutions = solve((eq1, eq2, eq3), (l1), dict=True)

# Display the solutions
simplified_solutions = [simplify(sol[l1]) for sol in solutions]
print(solutions)
